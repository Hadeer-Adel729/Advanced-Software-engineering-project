
public interface observer {
	
	public void update(boolean messages);

}
