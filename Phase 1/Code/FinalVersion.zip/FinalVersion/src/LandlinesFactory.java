
public interface LandlinesFactory {
	public double amount=0.0;
	public double fees=0.0;
	public double totalFees();

}
