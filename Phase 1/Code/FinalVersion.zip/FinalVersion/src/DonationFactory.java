
public interface DonationFactory {
double amount=0;
public double fees=0.0;
public double totalFees();
}
